//
//  oda_2_0App.swift
//  oda 2.0
//
//  Created by David Dichas on 24/10/2022.
//

import SwiftUI

@main
struct oda_2_0App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
